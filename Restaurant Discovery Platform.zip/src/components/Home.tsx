import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router';
import { ArrowUpDown } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { BrandCard } from './BrandCard';
import { brands, Brand } from '../utils/mockData';

export function Home() {
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryParam = searchParams.get('category') || 'All';
  const [selectedCategory, setSelectedCategory] = useState<string>(categoryParam);
  const [sortBy, setSortBy] = useState<string>('rating');
  const [filterArea, setFilterArea] = useState<string>('all');
  const [filterPrice, setFilterPrice] = useState<string>('all');

  useEffect(() => {
    setSelectedCategory(categoryParam);
  }, [categoryParam]);

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    if (category === 'All') {
      setSearchParams({});
    } else {
      setSearchParams({ category });
    }
  };

  // Get unique areas for filter
  const areas = useMemo(() => {
    const uniqueAreas = Array.from(new Set(brands.map(brand => brand.area)));
    return uniqueAreas.sort();
  }, []);

  // Get unique price levels for filter
  const priceLevels = ['$', '$$', '$$$', '$$$$'];

  const filteredAndSortedBrands = useMemo(() => {
    // First filter by category
    let filtered = selectedCategory === 'All' 
      ? brands 
      : brands.filter(brand => brand.category === selectedCategory);

    // Then filter by area
    if (filterArea !== 'all') {
      filtered = filtered.filter(brand => brand.area === filterArea);
    }

    // Then filter by price
    if (filterPrice !== 'all') {
      filtered = filtered.filter(brand => brand.priceLevel === filterPrice);
    }

    // Finally sort
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case 'rating':
          return b.rating - a.rating;
        case 'reviews':
          return b.reviewCount - a.reviewCount;
        case 'price-low':
          return a.priceLevel.length - b.priceLevel.length;
        case 'price-high':
          return b.priceLevel.length - a.priceLevel.length;
        case 'area':
          return a.area.localeCompare(b.area);
        default:
          return 0;
      }
    });

    return sorted;
  }, [selectedCategory, sortBy, filterArea, filterPrice]);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-orange-500 via-orange-400 to-yellow-400 text-white">
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-5xl mb-4">Discover Amazing Places</h1>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Explore the finest restaurants, lifestyle brands, and resorts with exclusive discounts
          </p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="sticky top-[73px] z-40 bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <Tabs value={selectedCategory} onValueChange={handleCategoryChange}>
            <TabsList className="w-full justify-start overflow-x-auto">
              <TabsTrigger value="All">All</TabsTrigger>
              <TabsTrigger value="Restaurant">Restaurants</TabsTrigger>
              <TabsTrigger value="Lifestyle">Lifestyle</TabsTrigger>
              <TabsTrigger value="Resort">Resorts</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Brand Grid */}
      <div className="container mx-auto px-4 py-8">
        {/* Filters and Sort */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <h2 className="text-gray-600">
              {filteredAndSortedBrands.length} {selectedCategory === 'All' ? 'place' : selectedCategory.toLowerCase()}{filteredAndSortedBrands.length !== 1 ? 's' : ''} found
            </h2>
          </div>
          
          <div className="flex flex-wrap gap-3">
            {/* Area Filter */}
            <Select value={filterArea} onValueChange={setFilterArea}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by Area" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Areas</SelectItem>
                {areas.map((area) => (
                  <SelectItem key={area} value={area}>
                    {area}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Price Filter */}
            <Select value={filterPrice} onValueChange={setFilterPrice}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by Price" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Prices</SelectItem>
                {priceLevels.map((price) => (
                  <SelectItem key={price} value={price}>
                    {price}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[200px]">
                <ArrowUpDown className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="reviews">Most Reviewed</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="area">Area (A-Z)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAndSortedBrands.map((brand) => (
            <BrandCard key={brand.id} brand={brand} />
          ))}
        </div>

        {filteredAndSortedBrands.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-500 text-lg">No brands found matching your filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
