import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { Tag, Copy, Check, Calendar, Sparkles } from 'lucide-react';
import { useAuth } from '../utils/authContext';
import { AuthModal } from './AuthModal';
import { SpinWheel } from './SpinWheel';
import type { Discount } from '../utils/mockData';

interface DiscountModalProps {
  discount: Discount;
  brandName: string;
}

export function DiscountModal({ discount, brandName }: DiscountModalProps) {
  const { isAuthenticated, user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [discountCode, setDiscountCode] = useState<string>('');
  const [wonDiscount, setWonDiscount] = useState<number | null>(null);
  const [wonOffer, setWonOffer] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [showWheel, setShowWheel] = useState(false);

  const generateDiscountCode = () => {
    // Generate unique code when modal opens
    const code = `DUOS${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
    setDiscountCode(code);
  };

  const handleDiscountClick = () => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
    } else {
      setIsOpen(true);
      setShowWheel(true);
    }
  };

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
    setIsOpen(true);
    setShowWheel(true);
  };

  const handleWheelWin = (discount: number, offer: string) => {
    setWonDiscount(discount);
    setWonOffer(offer);
    setShowWheel(false);
    generateDiscountCode();
  };

  const handleOpenChange = (open: boolean) => {
    setIsOpen(open);
    if (!open) {
      setCopied(false);
      setShowWheel(false);
      setWonDiscount(null);
      setWonOffer('');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(discountCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <Button 
        className="w-full bg-orange-500 hover:bg-orange-600 text-white" 
        onClick={handleDiscountClick}
      >
        <Tag className="h-4 w-4 mr-2" />
        Avail Discount
      </Button>

      <Dialog open={isOpen} onOpenChange={handleOpenChange}>
        <DialogContent className="sm:max-w-md">
          {showWheel ? (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-orange-500" />
                  Spin to Win!
                </DialogTitle>
                <DialogDescription>
                  Spin the wheel for your discount
                </DialogDescription>
              </DialogHeader>
              <SpinWheel onWin={handleWheelWin} />
            </>
          ) : (
            <>
              <DialogHeader>
                <DialogTitle>{discount.title}</DialogTitle>
                <DialogDescription>
                  {discount.description}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                {wonDiscount && (
                  <div className="bg-gradient-to-r from-orange-100 to-pink-100 border-2 border-orange-300 rounded-lg p-4 text-center">
                    <p className="text-sm text-gray-700 mb-1">🎉 Congratulations!</p>
                    <p className="text-xl text-orange-600">
                      You won {wonOffer}!
                    </p>
                  </div>
                )}

                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Calendar className="h-4 w-4" />
                  <span>Valid until: {new Date(discount.validUntil).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</span>
                </div>

                <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 rounded-lg p-6 text-center">
                  <p className="text-sm text-gray-600 mb-2">Your Unique Discount Code</p>
                  <div className="text-3xl tracking-wider mb-4 select-all text-orange-600">
                    {discountCode}
                  </div>
                  {wonDiscount && (
                    <p className="text-sm mb-3 text-gray-700">
                      Worth <span className="font-bold text-orange-600">{wonOffer}</span>
                    </p>
                  )}
                  <Button
                    onClick={copyToClipboard}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    {copied ? (
                      <>
                        <Check className="h-4 w-4 mr-2" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4 mr-2" />
                        Copy Code
                      </>
                    )}
                  </Button>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-800">
                    <strong>How to use:</strong> Show this unique code to the staff at {brandName} to avail your {wonOffer} discount. 
                    Screenshot or copy this code for easy access.
                  </p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)} 
        onSuccess={handleAuthSuccess} 
      />
    </>
  );
}