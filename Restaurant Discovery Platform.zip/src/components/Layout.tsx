import { Outlet } from 'react-router';
import { Header } from './Header';
import { AuthProvider } from '../utils/authContext';

export function Layout() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <Outlet />
      </div>
    </AuthProvider>
  );
}