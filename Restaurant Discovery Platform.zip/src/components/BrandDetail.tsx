import { useParams, Link } from 'react-router';
import { Star, MapPin, Phone, ExternalLink, ArrowLeft, Tag, Info } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { DiscountModal } from './DiscountModal';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { brands } from '../utils/mockData';

export function BrandDetail() {
  const { id } = useParams();
  const brand = brands.find(b => b.id === id);

  if (!brand) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Brand not found</h2>
          <Link to="/">
            <Button>Go Back Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const categoryColors = {
    Restaurant: 'bg-orange-100 text-orange-700 border-orange-200',
    Lifestyle: 'bg-purple-100 text-purple-700 border-purple-200',
    Resort: 'bg-blue-100 text-blue-700 border-blue-200'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Back Button */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Discover
            </Button>
          </Link>
          
          <Link to={`/partner/${id}`}>
            <Button variant="outline" size="sm">
              View Partner Dashboard
            </Button>
          </Link>
        </div>
      </div>

      {/* Hero Image Gallery */}
      <div className="bg-white">
        <div className="container mx-auto px-4 py-6">
          <div className="grid grid-cols-4 gap-2 h-[400px]">
            <div className="col-span-4 md:col-span-2 md:row-span-2">
              <ImageWithFallback
                src={brand.images[0]}
                alt={brand.name}
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            {brand.images.slice(1, 5).map((image, index) => (
              <div key={index} className="col-span-2 md:col-span-1 h-full">
                <ImageWithFallback
                  src={image}
                  alt={`${brand.name} ${index + 2}`}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Brand Info */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <div>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className={categoryColors[brand.category]}>
                      {brand.category}
                    </Badge>
                    <Badge variant="outline" className="text-green-600 border-green-600">
                      {brand.priceLevel}
                    </Badge>
                  </div>
                  <h1 className="mb-2">{brand.name}</h1>
                  <div className="flex items-center gap-4 mb-2">
                    <div className="flex items-center gap-1">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                      <span className="text-lg">{brand.rating}</span>
                    </div>
                    <span className="text-gray-500">
                      ({brand.reviewCount} reviews)
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="h-4 w-4" />
                    <span>{brand.area}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-700 text-lg">{brand.description}</p>
            </div>

            <Separator />

            {/* Tabs Content */}
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="about">About</TabsTrigger>
                <TabsTrigger value="photos">Photos</TabsTrigger>
                {brand.menu && <TabsTrigger value="menu">Menu</TabsTrigger>}
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>

              <TabsContent value="about" className="space-y-6 mt-6">
                {/* Interesting Facts */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Info className="h-5 w-5" />
                      Interesting Facts
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {brand.interestingFacts.map((fact, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <span className="text-orange-500 mt-1">•</span>
                          <span className="text-gray-700">{fact}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                {/* Contact Info */}
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                      <div>
                        <p className="text-gray-700">{brand.address}</p>
                        <a
                          href={brand.mapLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-orange-500 hover:text-orange-600 text-sm flex items-center gap-1 mt-1"
                        >
                          Open in Google Maps
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Phone className="h-5 w-5 text-gray-500" />
                      <a
                        href={`tel:${brand.contactNumber}`}
                        className="text-gray-700 hover:text-orange-500"
                      >
                        {brand.contactNumber}
                      </a>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="photos" className="mt-6">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {brand.images.map((image, index) => (
                    <div key={index} className="aspect-square">
                      <ImageWithFallback
                        src={image}
                        alt={`${brand.name} ${index + 1}`}
                        className="w-full h-full object-cover rounded-lg hover:opacity-90 transition-opacity"
                      />
                    </div>
                  ))}
                </div>
              </TabsContent>

              {brand.menu && (
                <TabsContent value="menu" className="mt-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Menu</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {Array.from(new Set(brand.menu.map(item => item.category))).map(category => (
                          <div key={category}>
                            <h3 className="mb-4 text-orange-500">{category}</h3>
                            <div className="space-y-4">
                              {brand.menu?.filter(item => item.category === category).map((item, index) => (
                                <div key={index} className="flex justify-between items-start gap-4">
                                  <div className="flex-1">
                                    <p className="text-gray-900">{item.name}</p>
                                    <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                                  </div>
                                  <span className="text-gray-900 whitespace-nowrap">{item.price}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              <TabsContent value="reviews" className="space-y-4 mt-6">
                {brand.reviews.map((review) => (
                  <Card key={review.id}>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-gray-900">{review.userName}</p>
                          <p className="text-sm text-gray-500">
                            {new Date(review.date).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            })}
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          <span>{review.rating}</span>
                        </div>
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-4">
              {/* Discount Offers */}
              <Card className="border-orange-200 bg-orange-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-orange-700">
                    <Tag className="h-5 w-5" />
                    Special Offers
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {brand.discounts.map((discount) => (
                    <div key={discount.id} className="space-y-2">
                      <div className="bg-white rounded-lg p-4 border border-orange-200">
                        <h4 className="text-gray-900 mb-2">{discount.title}</h4>
                        <p className="text-sm text-gray-600 mb-3">{discount.description}</p>
                        <p className="text-xs text-gray-500 mb-3">
                          Valid until {new Date(discount.validUntil).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric'
                          })}
                        </p>
                        <DiscountModal discount={discount} brandName={brand.name} />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <a href={brand.mapLink} target="_blank" rel="noopener noreferrer" className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <MapPin className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                  </a>
                  <a href={`tel:${brand.contactNumber}`} className="block">
                    <Button variant="outline" className="w-full justify-start">
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
