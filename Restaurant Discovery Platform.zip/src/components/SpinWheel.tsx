import { useState } from 'react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

interface SpinWheelProps {
  onWin: (discount: number, offer: string) => void;
}

const prizes = [
  { discount: 5, color: '#fef3c7', offer: '5% OFF' },
  { discount: 10, color: '#fde68a', offer: '10% OFF' },
  { discount: 15, color: '#fcd34d', offer: '15% OFF' },
  { discount: 20, color: '#fbbf24', offer: '20% OFF' },
  { discount: 8, color: '#fed7aa', offer: '8% OFF' },
  { discount: 12, color: '#fdba74', offer: '12% OFF' },
  { discount: 25, color: '#fb923c', offer: '25% OFF' },
  { discount: 7, color: '#f9a8d4', offer: '7% OFF' },
];

export function SpinWheel({ onWin }: SpinWheelProps) {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [hasSpun, setHasSpun] = useState(false);

  const spinWheel = () => {
    if (isSpinning || hasSpun) return;

    setIsSpinning(true);
    
    // Random prize selection
    const prizeIndex = Math.floor(Math.random() * prizes.length);
    const segmentAngle = 360 / prizes.length;
    
    // Calculate rotation to land on selected prize
    const baseRotation = 360 * 5; // 5 full rotations
    const prizeAngle = prizeIndex * segmentAngle;
    const targetRotation = baseRotation + (360 - prizeAngle) + segmentAngle / 2;
    
    setRotation(targetRotation);

    // After animation completes
    setTimeout(() => {
      setIsSpinning(false);
      setHasSpun(true);
      const wonPrize = prizes[prizeIndex];
      onWin(wonPrize.discount, wonPrize.offer);
    }, 4000);
  };

  return (
    <div className="flex flex-col items-center py-6">
      <div className="mb-6 text-center">
        <h3 className="text-xl mb-2">Spin to Win Your Discount!</h3>
        <p className="text-sm text-gray-600">
          Spin the wheel for a chance to win up to 25% OFF
        </p>
      </div>

      {/* Wheel Container */}
      <div className="relative mb-8">
        {/* Pointer */}
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 z-10">
          <div className="w-0 h-0 border-l-[15px] border-l-transparent border-r-[15px] border-r-transparent border-t-[30px] border-t-red-500" />
        </div>

        {/* Wheel */}
        <motion.div
          className="relative w-72 h-72 rounded-full border-8 border-gray-800 shadow-2xl overflow-hidden"
          animate={{ rotate: rotation }}
          transition={{
            duration: 4,
            ease: [0.17, 0.67, 0.12, 0.99],
          }}
          style={{
            background: 'conic-gradient(' +
              prizes.map((prize, i) => {
                const startAngle = (i * 360) / prizes.length;
                const endAngle = ((i + 1) * 360) / prizes.length;
                return `${prize.color} ${startAngle}deg ${endAngle}deg`;
              }).join(', ') + ')',
          }}
        >
          {/* Prize Segments */}
          {prizes.map((prize, index) => {
            const angle = (360 / prizes.length) * index;
            return (
              <div
                key={index}
                className="absolute top-1/2 left-1/2 origin-left"
                style={{
                  transform: `rotate(${angle + 360 / prizes.length / 2}deg)`,
                  width: '50%',
                }}
              >
                <div className="pl-4 py-2">
                  <span className="text-lg font-bold text-gray-800">
                    {prize.offer}
                  </span>
                </div>
              </div>
            );
          })}

          {/* Center Circle */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white rounded-full border-4 border-gray-800 flex items-center justify-center shadow-lg">
            <Sparkles className="h-6 w-6 text-orange-500" />
          </div>
        </motion.div>
      </div>

      <Button
        onClick={spinWheel}
        disabled={isSpinning || hasSpun}
        size="lg"
        className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white px-8"
      >
        {isSpinning ? 'Spinning...' : hasSpun ? 'Already Spun!' : 'SPIN NOW'}
      </Button>

      {hasSpun && (
        <p className="mt-4 text-sm text-gray-600">
          Your discount code will appear after the spin!
        </p>
      )}
    </div>
  );
}