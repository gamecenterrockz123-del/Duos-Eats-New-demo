import { Link } from 'react-router';
import { Star, MapPin, Phone, DollarSign } from 'lucide-react';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Brand } from '../utils/mockData';

interface BrandCardProps {
  brand: Brand;
}

export function BrandCard({ brand }: BrandCardProps) {
  const categoryColors = {
    Restaurant: 'bg-orange-100 text-orange-700 border-orange-200',
    Lifestyle: 'bg-purple-100 text-purple-700 border-purple-200',
    Resort: 'bg-blue-100 text-blue-700 border-blue-200'
  };

  return (
    <Link to={`/brand/${brand.id}`}>
      <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer group h-full">
        <div className="relative h-56 overflow-hidden">
          <ImageWithFallback
            src={brand.images[0]}
            alt={brand.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-3 right-3 flex gap-2">
            <Badge className={categoryColors[brand.category]}>
              {brand.category}
            </Badge>
          </div>
          {brand.discounts.length > 0 && (
            <div className="absolute top-3 left-3">
              <Badge className="bg-red-500 text-white border-red-600">
                {brand.discounts.length} Offer{brand.discounts.length > 1 ? 's' : ''}
              </Badge>
            </div>
          )}
        </div>
        
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-2">
            <h3 className="flex-1">{brand.name}</h3>
            <span className="text-green-600 ml-2">{brand.priceLevel}</span>
          </div>
          
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm">{brand.rating}</span>
            </div>
            <span className="text-sm text-gray-500">
              ({brand.reviewCount} reviews)
            </span>
          </div>
          
          <p className="text-sm text-gray-600 mb-4 line-clamp-2">
            {brand.description}
          </p>
          
          <div className="flex items-center gap-2 text-sm mb-2">
            <MapPin className="h-4 w-4 text-gray-500" />
            <span className="text-gray-900">{brand.area}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Phone className="h-4 w-4" />
            <span>{brand.contactNumber}</span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
