import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { DollarSign, Store, Users, Eye, Tag, TrendingUp, ArrowUpDown, Search } from 'lucide-react';
import { useState } from 'react';
import {
  monthlyRevenueData,
  userGrowthData,
  discountRedemptionData,
  adminStats,
  recentSubscriptions,
  subscriptionPlans,
  restaurantAnalytics,
} from '../utils/adminData';

export function AdminDashboard() {
  const [sortBy, setSortBy] = useState<'visits' | 'claims' | 'conversion'>('visits');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  const toggleSort = (field: 'visits' | 'claims' | 'conversion') => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const filteredAndSortedRestaurants = restaurantAnalytics
    .filter((restaurant) => {
      const matchesSearch = restaurant.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || restaurant.category === categoryFilter;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      let compareValue = 0;
      if (sortBy === 'visits') {
        compareValue = a.profileVisits - b.profileVisits;
      } else if (sortBy === 'claims') {
        compareValue = a.discountClaims - b.discountClaims;
      } else {
        compareValue = a.conversionRate - b.conversionRate;
      }
      return sortOrder === 'asc' ? compareValue : -compareValue;
    });

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Admin Dashboard</h1>
        <p className="text-gray-600">Manage and monitor Duos Eats platform</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">${adminStats.totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">From subscriptions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Restaurants</CardTitle>
            <Store className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{adminStats.totalRestaurants}</div>
            <p className="text-xs text-gray-500 mt-1">Active listings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Registered Users</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{adminStats.registeredUsers.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Total accounts</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Total Visitors</CardTitle>
            <Eye className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{adminStats.totalVisitors.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Platform views</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm">Discount Claims</CardTitle>
            <Tag className="h-4 w-4 text-pink-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{adminStats.discountRedemptions.toLocaleString()}</div>
            <p className="text-xs text-gray-500 mt-1">Total redemptions</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <Tabs defaultValue="revenue" className="mb-8">
        <TabsList>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="users">User Growth</TabsTrigger>
          <TabsTrigger value="redemptions">Discount Redemptions</TabsTrigger>
          <TabsTrigger value="restaurants">Restaurant Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue</CardTitle>
              <CardDescription>Subscription revenue over the past year</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={monthlyRevenueData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => `$${value.toLocaleString()}`}
                    contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }}
                  />
                  <Legend />
                  <Bar dataKey="revenue" fill="#f97316" name="Revenue ($)" />
                  <Bar dataKey="subscriptions" fill="#3b82f6" name="New Subscriptions" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Growth</CardTitle>
              <CardDescription>Registered users over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={userGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="users" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    name="Total Users"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="redemptions">
          <Card>
            <CardHeader>
              <CardTitle>Discount Redemptions</CardTitle>
              <CardDescription>Monthly discount code claims</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={discountRedemptionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc' }} />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="redemptions" 
                    stroke="#ec4899" 
                    strokeWidth={2}
                    name="Redemptions"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="restaurants">
          <Card>
            <CardHeader>
              <CardTitle>Restaurant Performance</CardTitle>
              <CardDescription>Track profile visits and discount claims by restaurant</CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search restaurants..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={categoryFilter === 'All' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCategoryFilter('All')}
                  >
                    All
                  </Button>
                  <Button
                    variant={categoryFilter === 'Restaurant' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCategoryFilter('Restaurant')}
                  >
                    Restaurants
                  </Button>
                  <Button
                    variant={categoryFilter === 'Lifestyle' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCategoryFilter('Lifestyle')}
                  >
                    Lifestyle
                  </Button>
                  <Button
                    variant={categoryFilter === 'Resort' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setCategoryFilter('Resort')}
                  >
                    Resorts
                  </Button>
                </div>
              </div>

              {/* Table */}
              <div className="border rounded-lg overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">
                          Restaurant
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">
                          Category
                        </th>
                        <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">
                          Plan
                        </th>
                        <th 
                          className="px-4 py-3 text-left text-sm font-medium text-gray-700 cursor-pointer hover:bg-gray-100"
                          onClick={() => toggleSort('visits')}
                        >
                          <div className="flex items-center gap-1">
                            Profile Visits
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="px-4 py-3 text-left text-sm font-medium text-gray-700 cursor-pointer hover:bg-gray-100"
                          onClick={() => toggleSort('claims')}
                        >
                          <div className="flex items-center gap-1">
                            Discount Claims
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                        <th 
                          className="px-4 py-3 text-left text-sm font-medium text-gray-700 cursor-pointer hover:bg-gray-100"
                          onClick={() => toggleSort('conversion')}
                        >
                          <div className="flex items-center gap-1">
                            Conversion Rate
                            <ArrowUpDown className="h-3 w-3" />
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {filteredAndSortedRestaurants.map((restaurant) => (
                        <tr key={restaurant.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div className="font-medium">{restaurant.name}</div>
                            <div className="text-xs text-gray-500">
                              Active {new Date(restaurant.lastActive).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <Badge variant="outline">{restaurant.category}</Badge>
                          </td>
                          <td className="px-4 py-3">
                            <Badge
                              variant={
                                restaurant.subscriptionPlan === 'Premium'
                                  ? 'default'
                                  : 'secondary'
                              }
                            >
                              {restaurant.subscriptionPlan}
                            </Badge>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <Eye className="h-4 w-4 text-purple-600" />
                              <span className="font-medium">{restaurant.profileVisits.toLocaleString()}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <Tag className="h-4 w-4 text-pink-600" />
                              <span className="font-medium">{restaurant.discountClaims.toLocaleString()}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-green-600">
                                {restaurant.conversionRate}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Summary */}
              <div className="mt-4 flex items-center justify-between text-sm text-gray-600">
                <span>Showing {filteredAndSortedRestaurants.length} of {restaurantAnalytics.length} restaurants</span>
                <span>
                  Total: {filteredAndSortedRestaurants.reduce((sum, r) => sum + r.profileVisits, 0).toLocaleString()} visits, {' '}
                  {filteredAndSortedRestaurants.reduce((sum, r) => sum + r.discountClaims, 0).toLocaleString()} claims
                </span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Subscriptions */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Subscriptions</CardTitle>
            <CardDescription>Latest restaurant subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSubscriptions.map((subscription) => (
                <div
                  key={subscription.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <p className="font-medium">{subscription.restaurantName}</p>
                    <p className="text-sm text-gray-500">{subscription.plan} Plan</p>
                  </div>
                  <div className="text-right mr-4">
                    <p className="font-medium text-green-600">${subscription.amount}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(subscription.date).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                      })}
                    </p>
                  </div>
                  <Badge
                    variant={subscription.status === 'active' ? 'default' : 'secondary'}
                  >
                    {subscription.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Subscription Plans */}
        <Card>
          <CardHeader>
            <CardTitle>Subscription Plans</CardTitle>
            <CardDescription>Plan distribution and pricing</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {subscriptionPlans.map((plan) => (
                <div
                  key={plan.name}
                  className="p-4 border rounded-lg hover:border-orange-300 transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="font-medium">{plan.name}</h3>
                      <p className="text-2xl text-orange-600">${plan.price}/mo</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <span className="text-2xl">{plan.count}</span>
                      </div>
                      <p className="text-xs text-gray-500">subscribers</p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {plan.features.slice(0, 3).map((feature, idx) => (
                      <p key={idx} className="text-sm text-gray-600">
                        • {feature}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}