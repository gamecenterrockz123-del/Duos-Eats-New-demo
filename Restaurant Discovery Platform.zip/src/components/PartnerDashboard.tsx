import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { ArrowLeft, Eye, Tag, TrendingUp, Users, Smartphone, Monitor, Tablet, Check, Clock, Calendar, Mail, Phone } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { brands } from '../utils/mockData';
import { getAnalytics } from '../utils/analyticsData';

export function PartnerDashboard() {
  const { id } = useParams();
  const brand = brands.find(b => b.id === id);
  const analytics = id ? getAnalytics(id) : null;

  if (!brand || !analytics) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="mb-4">Dashboard not found</h2>
          <Link to="/">
            <Button>Go Back Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const deviceIcon = (device: string) => {
    switch (device) {
      case 'Mobile':
        return <Smartphone className="h-4 w-4" />;
      case 'Desktop':
        return <Monitor className="h-4 w-4" />;
      case 'Tablet':
        return <Tablet className="h-4 w-4" />;
      default:
        return <Monitor className="h-4 w-4" />;
    }
  };

  const redemptionRate = analytics.totalDiscountClaims > 0
    ? ((analytics.totalRedemptions / analytics.totalDiscountClaims) * 100).toFixed(1)
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Brand Header */}
        <div className="mb-8">
          <h1 className="mb-2">Partner Dashboard</h1>
          <p className="text-xl text-gray-600">{brand.name}</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-600 flex items-center gap-2">
                <Eye className="h-4 w-4" />
                Total Profile Views
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{analytics.totalProfileViews.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">All time views</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-600 flex items-center gap-2">
                <Tag className="h-4 w-4" />
                Discount Claims
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{analytics.totalDiscountClaims.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">Codes generated</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-600 flex items-center gap-2">
                <Users className="h-4 w-4" />
                Redemptions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{analytics.totalRedemptions.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">Visited restaurant</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-gray-600 flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Conversion Rate
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl">{redemptionRate}%</div>
              <p className="text-xs text-gray-500 mt-1">Claim to visit ratio</p>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Analytics */}
        <Tabs defaultValue="views" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md">
            <TabsTrigger value="views">Profile Views</TabsTrigger>
            <TabsTrigger value="claims">Discount Claims</TabsTrigger>
          </TabsList>

          {/* Profile Views Tab */}
          <TabsContent value="views" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Profile Views</CardTitle>
                <CardDescription>
                  Users who viewed your brand profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics.profileViews.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No profile views yet</p>
                  ) : (
                    analytics.profileViews.map((view) => (
                      <div
                        key={view.id}
                        className="flex items-start justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center text-white">
                              {view.userName.charAt(0)}
                            </div>
                            <div>
                              <p className="text-gray-900">{view.userName}</p>
                              <div className="flex items-center gap-2 text-sm text-gray-500">
                                <Mail className="h-3 w-3" />
                                <span>{view.userEmail}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 ml-13 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>{formatDateTime(view.viewedAt)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>Viewed for {formatDuration(view.duration)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {deviceIcon(view.deviceType)}
                              <span>{view.deviceType}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Discount Claims Tab */}
          <TabsContent value="claims" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Discount Claims & Redemptions</CardTitle>
                <CardDescription>
                  Track which customers claimed and redeemed your offers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {analytics.discountClaims.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">No discount claims yet</p>
                  ) : (
                    analytics.discountClaims.map((claim) => (
                      <div
                        key={claim.id}
                        className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center text-white">
                              {claim.userName.charAt(0)}
                            </div>
                            <div>
                              <p className="text-gray-900">{claim.userName}</p>
                              <div className="flex items-center gap-3 text-sm text-gray-500">
                                <div className="flex items-center gap-1">
                                  <Mail className="h-3 w-3" />
                                  <span>{claim.userEmail}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Phone className="h-3 w-3" />
                                  <span>{claim.userPhone}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <Badge
                            className={
                              claim.isRedeemed
                                ? 'bg-green-100 text-green-700 border-green-200'
                                : 'bg-yellow-100 text-yellow-700 border-yellow-200'
                            }
                          >
                            {claim.isRedeemed ? (
                              <>
                                <Check className="h-3 w-3 mr-1" />
                                Redeemed
                              </>
                            ) : (
                              <>
                                <Clock className="h-3 w-3 mr-1" />
                                Pending
                              </>
                            )}
                          </Badge>
                        </div>

                        <div className="ml-13 space-y-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <p className="text-sm text-gray-600 mb-1">Offer</p>
                              <p className="text-gray-900">{claim.discountTitle}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-600 mb-1">Code</p>
                              <p className="text-orange-600 tracking-wide">{claim.discountCode}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-6 text-sm pt-2 border-t">
                            <div>
                              <span className="text-gray-600">Claimed: </span>
                              <span className="text-gray-900">{formatDate(claim.claimedAt)}</span>
                            </div>
                            {claim.isRedeemed && claim.redeemedAt && (
                              <div>
                                <span className="text-gray-600">Visited: </span>
                                <span className="text-green-600">{formatDate(claim.redeemedAt)}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
