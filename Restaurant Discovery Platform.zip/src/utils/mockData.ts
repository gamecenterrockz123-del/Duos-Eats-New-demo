export interface Brand {
  id: string;
  name: string;
  category: 'Restaurant' | 'Lifestyle' | 'Resort';
  description: string;
  rating: number;
  reviewCount: number;
  images: string[];
  contactNumber: string;
  address: string;
  area: string;
  priceLevel: '$' | '$$' | '$$$' | '$$$$';
  mapLink: string;
  discounts: Discount[];
  menu?: MenuItem[];
  reviews: Review[];
  interestingFacts: string[];
}

export interface Discount {
  id: string;
  title: string;
  description: string;
  validUntil: string;
}

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  category: string;
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  avatar?: string;
}

export const brands: Brand[] = [
  {
    id: '1',
    name: 'The Golden Spoon',
    category: 'Restaurant',
    description: 'Award-winning fine dining restaurant offering contemporary European cuisine with a modern twist.',
    rating: 4.8,
    reviewCount: 342,
    images: [
      'https://images.unsplash.com/photo-1744776411221-702f2848b0b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjByZXN0YXVyYW50JTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY0NDE4MzUyfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1558199141-391d935676f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5lJTIwZGluaW5nJTIwZm9vZHxlbnwxfHx8fDE3NjQ0MTkyNzZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1080',
      'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c?w=1080'
    ],
    contactNumber: '+1 (555) 123-4567',
    address: '123 Gourmet Avenue, Downtown District',
    area: 'Downtown District',
    priceLevel: '$$$$',
    mapLink: 'https://maps.google.com/?q=123+Gourmet+Avenue+Downtown+District',
    discounts: [
      {
        id: 'd1',
        title: '20% Off on Weekday Lunch',
        description: 'Enjoy 20% discount on all lunch menu items from Monday to Friday',
        validUntil: '2025-12-31'
      },
      {
        id: 'd2',
        title: 'Complimentary Dessert',
        description: 'Get a free dessert with any main course order',
        validUntil: '2025-12-31'
      }
    ],
    menu: [
      {
        name: 'Pan-Seared Scallops',
        description: 'Fresh sea scallops with lemon butter sauce and seasonal vegetables',
        price: '$42',
        category: 'Appetizers'
      },
      {
        name: 'Truffle Risotto',
        description: 'Creamy arborio rice with black truffle and parmesan',
        price: '$38',
        category: 'Main Course'
      },
      {
        name: 'Wagyu Beef Tenderloin',
        description: 'Premium Japanese wagyu with red wine reduction',
        price: '$85',
        category: 'Main Course'
      },
      {
        name: 'Chocolate Soufflé',
        description: 'Classic French chocolate soufflé with vanilla ice cream',
        price: '$16',
        category: 'Desserts'
      }
    ],
    reviews: [
      {
        id: 'r1',
        userName: 'Sarah Johnson',
        rating: 5,
        date: '2025-11-15',
        comment: 'Absolutely incredible experience! The food was divine and the service was impeccable. The truffle risotto is a must-try!'
      },
      {
        id: 'r2',
        userName: 'Michael Chen',
        rating: 4,
        date: '2025-11-10',
        comment: 'Great atmosphere and delicious food. Slightly pricey but worth it for special occasions.'
      },
      {
        id: 'r3',
        userName: 'Emma Davis',
        rating: 5,
        date: '2025-11-05',
        comment: 'The wagyu beef was cooked to perfection. Best fine dining experience in the city!'
      }
    ],
    interestingFacts: [
      'Winner of 3 Michelin Stars',
      'Chef trained in Paris under renowned chefs',
      'Ingredients sourced from local organic farms',
      'Signature wine collection with over 500 labels'
    ]
  },
  {
    id: '2',
    name: 'Zenith Wellness Spa',
    category: 'Lifestyle',
    description: 'Premium wellness and spa retreat offering holistic treatments and mindfulness experiences.',
    rating: 4.9,
    reviewCount: 528,
    images: [
      'https://images.unsplash.com/photo-1761470575018-135c213340eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGElMjB3ZWxsbmVzcyUyMHJlc29ydHxlbnwxfHx8fDE3NjQ0NDg0NTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=1080',
      'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=1080'
    ],
    contactNumber: '+1 (555) 234-5678',
    address: '456 Serenity Lane, Wellness District',
    area: 'Wellness District',
    priceLevel: '$$$',
    mapLink: 'https://maps.google.com/?q=456+Serenity+Lane+Wellness+District',
    discounts: [
      {
        id: 'd3',
        title: '30% Off First Visit',
        description: 'New customers receive 30% off their first treatment package',
        validUntil: '2025-12-31'
      },
      {
        id: 'd4',
        title: 'Couple Package Special',
        description: 'Book couple massage and get complimentary aromatherapy session',
        validUntil: '2025-12-31'
      }
    ],
    reviews: [
      {
        id: 'r4',
        userName: 'Jennifer Lee',
        rating: 5,
        date: '2025-11-20',
        comment: 'Most relaxing spa experience ever. The therapists are highly skilled and the ambiance is perfect.'
      },
      {
        id: 'r5',
        userName: 'David Park',
        rating: 5,
        date: '2025-11-18',
        comment: 'Amazing facility with state-of-the-art equipment. The hot stone massage was incredible!'
      },
      {
        id: 'r6',
        userName: 'Lisa Anderson',
        rating: 4,
        date: '2025-11-12',
        comment: 'Beautiful spa with great treatments. A bit expensive but the quality is worth it.'
      }
    ],
    interestingFacts: [
      'Featured in Vogue Wellness magazine',
      'Uses only organic and cruelty-free products',
      'Offers specialized treatments from Thai and Balinese traditions',
      'Private meditation gardens with panoramic city views'
    ]
  },
  {
    id: '3',
    name: 'Paradise Cove Resort',
    category: 'Resort',
    description: 'Luxury beachfront resort with world-class amenities, private villas, and stunning ocean views.',
    rating: 4.7,
    reviewCount: 1247,
    images: [
      'https://images.unsplash.com/photo-1722409195473-d322e99621e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjByZXNvcnQlMjBwb29sfGVufDF8fHx8MTc2NDM5NTQ0NXww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=1080',
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=1080',
      'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=1080'
    ],
    contactNumber: '+1 (555) 345-6789',
    address: '789 Ocean Drive, Coastal Paradise',
    area: 'Coastal Paradise',
    priceLevel: '$$$$',
    mapLink: 'https://maps.google.com/?q=789+Ocean+Drive+Coastal+Paradise',
    discounts: [
      {
        id: 'd5',
        title: 'Early Bird Special - 25% Off',
        description: 'Book 60 days in advance and save 25% on your stay',
        validUntil: '2025-12-31'
      },
      {
        id: 'd6',
        title: 'Extended Stay Discount',
        description: 'Stay 5 nights or more and get 7th night free',
        validUntil: '2025-12-31'
      }
    ],
    reviews: [
      {
        id: 'r7',
        userName: 'Robert Martinez',
        rating: 5,
        date: '2025-11-22',
        comment: 'Paradise indeed! The private beach is stunning and the staff went above and beyond. Will definitely return!'
      },
      {
        id: 'r8',
        userName: 'Amanda White',
        rating: 4,
        date: '2025-11-19',
        comment: 'Beautiful resort with excellent facilities. The infinity pool overlooking the ocean is breathtaking.'
      },
      {
        id: 'r9',
        userName: 'James Wilson',
        rating: 5,
        date: '2025-11-14',
        comment: 'Perfect honeymoon destination. Romantic setting, amazing food, and impeccable service.'
      }
    ],
    interestingFacts: [
      'Private beach spanning 2 miles',
      '5-star rating from Forbes Travel Guide',
      'Award-winning spa and wellness center on-site',
      'Offers water sports including scuba diving and paddleboarding',
      'Sustainability certified - 100% renewable energy'
    ]
  },
  {
    id: '4',
    name: 'Urban Brew Coffee House',
    category: 'Lifestyle',
    description: 'Artisan coffee house with locally roasted beans, coworking space, and community events.',
    rating: 4.6,
    reviewCount: 892,
    images: [
      'https://images.unsplash.com/photo-1758426637742-80bd0f983611?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjYWZlJTIwbGlmZXN0eWxlfGVufDF8fHx8MTc2NDQ0ODQ1Mnww&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=1080',
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=1080'
    ],
    contactNumber: '+1 (555) 456-7890',
    address: '321 Coffee Street, Arts Quarter',
    area: 'Arts Quarter',
    priceLevel: '$$',
    mapLink: 'https://maps.google.com/?q=321+Coffee+Street+Arts+Quarter',
    discounts: [
      {
        id: 'd7',
        title: 'Loyalty Card - Buy 5 Get 1 Free',
        description: 'Get your 6th coffee free with our digital loyalty card',
        validUntil: '2025-12-31'
      },
      {
        id: 'd8',
        title: 'Happy Hour - 15% Off',
        description: 'All beverages 15% off between 2-4 PM daily',
        validUntil: '2025-12-31'
      }
    ],
    menu: [
      {
        name: 'Signature Espresso',
        description: 'Single origin Ethiopian beans, perfectly extracted',
        price: '$4.50',
        category: 'Coffee'
      },
      {
        name: 'Matcha Latte',
        description: 'Premium ceremonial grade matcha with oat milk',
        price: '$6',
        category: 'Specialty Drinks'
      },
      {
        name: 'Avocado Toast',
        description: 'Sourdough with smashed avocado, cherry tomatoes, and feta',
        price: '$12',
        category: 'Food'
      }
    ],
    reviews: [
      {
        id: 'r10',
        userName: 'Sophie Taylor',
        rating: 5,
        date: '2025-11-25',
        comment: 'Best coffee in town! The atmosphere is perfect for working and the baristas are super friendly.'
      },
      {
        id: 'r11',
        userName: 'Mark Thompson',
        rating: 4,
        date: '2025-11-23',
        comment: 'Great coffee and vibe. Can get crowded on weekends but worth the wait.'
      }
    ],
    interestingFacts: [
      'Roasts coffee beans in-house weekly',
      'Hosts local artist exhibitions monthly',
      'Free high-speed WiFi and power outlets at every table',
      'Sustainable packaging - 100% compostable cups'
    ]
  },
  {
    id: '5',
    name: 'Sakura Sushi Bar',
    category: 'Restaurant',
    description: 'Authentic Japanese cuisine with fresh sushi, sashimi, and traditional dishes prepared by master chefs.',
    rating: 4.7,
    reviewCount: 645,
    images: [
      'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=1080',
      'https://images.unsplash.com/photo-1553621042-f6e147245754?w=1080',
      'https://images.unsplash.com/photo-1564489563601-c53cfc451e93?w=1080'
    ],
    contactNumber: '+1 (555) 567-8901',
    address: '654 Bamboo Boulevard, Japan Town',
    area: 'Japan Town',
    priceLevel: '$$$',
    mapLink: 'https://maps.google.com/?q=654+Bamboo+Boulevard+Japan+Town',
    discounts: [
      {
        id: 'd9',
        title: 'All-You-Can-Eat Lunch - $5 Off',
        description: 'Save $5 on our weekday lunch buffet',
        validUntil: '2025-12-31'
      },
      {
        id: 'd10',
        title: 'Sake Pairing Special',
        description: 'Free premium sake flight with omakase tasting menu',
        validUntil: '2025-12-31'
      }
    ],
    menu: [
      {
        name: 'Omakase Experience',
        description: "Chef's selection of premium sushi and sashimi (18 pieces)",
        price: '$95',
        category: 'Special'
      },
      {
        name: 'Dragon Roll',
        description: 'Eel, cucumber, avocado topped with tobiko',
        price: '$18',
        category: 'Specialty Rolls'
      },
      {
        name: 'Tuna Sashimi',
        description: 'Fresh bluefin tuna, 8 pieces',
        price: '$24',
        category: 'Sashimi'
      },
      {
        name: 'Miso Black Cod',
        description: 'Marinated black cod with miso glaze',
        price: '$32',
        category: 'Hot Dishes'
      }
    ],
    reviews: [
      {
        id: 'r12',
        userName: 'Kevin Zhang',
        rating: 5,
        date: '2025-11-26',
        comment: 'Hands down the best sushi in the city. Fish is incredibly fresh and the presentation is beautiful.'
      },
      {
        id: 'r13',
        userName: 'Maria Garcia',
        rating: 5,
        date: '2025-11-21',
        comment: 'The omakase was an unforgettable experience. Chef was engaging and knowledgeable.'
      },
      {
        id: 'r14',
        userName: 'Tom Brown',
        rating: 4,
        date: '2025-11-17',
        comment: 'Excellent quality sushi. A bit pricey but you get what you pay for.'
      }
    ],
    interestingFacts: [
      'Head chef trained in Tokyo for 15 years',
      'Fish flown in daily from Tsukiji Market',
      'Traditional Edomae-style sushi preparation',
      'Intimate 12-seat sushi counter experience'
    ]
  },
  {
    id: '6',
    name: 'Mountain Peak Lodge',
    category: 'Resort',
    description: 'Alpine resort offering skiing, hiking, and year-round mountain adventures with cozy luxury accommodations.',
    rating: 4.8,
    reviewCount: 934,
    images: [
      'https://images.unsplash.com/photo-1664186771971-2eaca0576c6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3V0aXF1ZSUyMGhvdGVsJTIwbG9iYnl8ZW58MXx8fHwxNzY0NDQ4NDUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=1080',
      'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1080'
    ],
    contactNumber: '+1 (555) 678-9012',
    address: '987 Summit Road, Mountain Valley',
    area: 'Mountain Valley',
    priceLevel: '$$$',
    mapLink: 'https://maps.google.com/?q=987+Summit+Road+Mountain+Valley',
    discounts: [
      {
        id: 'd11',
        title: 'Ski Package - 20% Off',
        description: 'Accommodation + lift passes package at 20% discount',
        validUntil: '2026-03-31'
      },
      {
        id: 'd12',
        title: 'Summer Adventure Deal',
        description: 'Free guided hiking tour with 3+ night booking',
        validUntil: '2025-09-30'
      }
    ],
    reviews: [
      {
        id: 'r15',
        userName: 'Chris Anderson',
        rating: 5,
        date: '2025-11-28',
        comment: 'Perfect ski resort! Excellent slopes, comfortable rooms, and the après-ski lounge is fantastic.'
      },
      {
        id: 'r16',
        userName: 'Rachel Moore',
        rating: 5,
        date: '2025-11-24',
        comment: 'Came for summer hiking and it was spectacular. The mountain views are breathtaking!'
      },
      {
        id: 'r17',
        userName: 'Daniel Kim',
        rating: 4,
        date: '2025-11-20',
        comment: 'Great family resort. Kids loved the ski school and we enjoyed the spa.'
      }
    ],
    interestingFacts: [
      'Direct ski-in/ski-out access',
      '50+ miles of mountain trails',
      'Award-winning alpine restaurant',
      'Year-round heated outdoor pool',
      'Private helicopter tours available'
    ]
  }
];
