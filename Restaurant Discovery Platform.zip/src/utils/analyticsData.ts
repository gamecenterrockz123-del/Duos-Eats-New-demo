export interface ProfileView {
  id: string;
  userName: string;
  userEmail: string;
  viewedAt: string;
  duration: number; // in seconds
  deviceType: 'Mobile' | 'Desktop' | 'Tablet';
}

export interface DiscountClaim {
  id: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  discountTitle: string;
  discountCode: string;
  claimedAt: string;
  isRedeemed: boolean;
  redeemedAt?: string;
}

export interface BrandAnalytics {
  brandId: string;
  totalProfileViews: number;
  totalDiscountClaims: number;
  totalRedemptions: number;
  profileViews: ProfileView[];
  discountClaims: DiscountClaim[];
}

// Mock analytics data for different brands
export const analyticsData: Record<string, BrandAnalytics> = {
  '1': { // The Golden Spoon
    brandId: '1',
    totalProfileViews: 342,
    totalDiscountClaims: 89,
    totalRedemptions: 67,
    profileViews: [
      {
        id: 'pv1',
        userName: 'Emily Rodriguez',
        userEmail: 'emily.r@email.com',
        viewedAt: '2025-11-29T10:30:00',
        duration: 245,
        deviceType: 'Mobile'
      },
      {
        id: 'pv2',
        userName: 'James Patterson',
        userEmail: 'james.p@email.com',
        viewedAt: '2025-11-29T09:15:00',
        duration: 180,
        deviceType: 'Desktop'
      },
      {
        id: 'pv3',
        userName: 'Sophia Chen',
        userEmail: 'sophia.c@email.com',
        viewedAt: '2025-11-28T18:45:00',
        duration: 320,
        deviceType: 'Mobile'
      },
      {
        id: 'pv4',
        userName: 'Marcus Johnson',
        userEmail: 'marcus.j@email.com',
        viewedAt: '2025-11-28T16:20:00',
        duration: 156,
        deviceType: 'Desktop'
      },
      {
        id: 'pv5',
        userName: 'Olivia Martinez',
        userEmail: 'olivia.m@email.com',
        viewedAt: '2025-11-28T14:30:00',
        duration: 290,
        deviceType: 'Tablet'
      },
      {
        id: 'pv6',
        userName: 'Liam O\'Brien',
        userEmail: 'liam.ob@email.com',
        viewedAt: '2025-11-27T19:10:00',
        duration: 210,
        deviceType: 'Mobile'
      },
      {
        id: 'pv7',
        userName: 'Ava Thompson',
        userEmail: 'ava.t@email.com',
        viewedAt: '2025-11-27T12:05:00',
        duration: 175,
        deviceType: 'Desktop'
      },
      {
        id: 'pv8',
        userName: 'Noah Williams',
        userEmail: 'noah.w@email.com',
        viewedAt: '2025-11-26T20:30:00',
        duration: 265,
        deviceType: 'Mobile'
      }
    ],
    discountClaims: [
      {
        id: 'dc1',
        userName: 'Emily Rodriguez',
        userEmail: 'emily.r@email.com',
        userPhone: '+1 (555) 901-2345',
        discountTitle: '20% Off on Weekday Lunch',
        discountCode: 'DUOSA8F3G2',
        claimedAt: '2025-11-29T10:35:00',
        isRedeemed: true,
        redeemedAt: '2025-11-29T12:15:00'
      },
      {
        id: 'dc2',
        userName: 'Sophia Chen',
        userEmail: 'sophia.c@email.com',
        userPhone: '+1 (555) 902-3456',
        discountTitle: 'Complimentary Dessert',
        discountCode: 'DUOSB9K4H3',
        claimedAt: '2025-11-28T18:50:00',
        isRedeemed: true,
        redeemedAt: '2025-11-28T19:30:00'
      },
      {
        id: 'dc3',
        userName: 'Marcus Johnson',
        userEmail: 'marcus.j@email.com',
        userPhone: '+1 (555) 903-4567',
        discountTitle: '20% Off on Weekday Lunch',
        discountCode: 'DUOSC1L5J4',
        claimedAt: '2025-11-28T16:25:00',
        isRedeemed: false
      },
      {
        id: 'dc4',
        userName: 'Liam O\'Brien',
        userEmail: 'liam.ob@email.com',
        userPhone: '+1 (555) 904-5678',
        discountTitle: 'Complimentary Dessert',
        discountCode: 'DUOSD2M6K5',
        claimedAt: '2025-11-27T19:15:00',
        isRedeemed: true,
        redeemedAt: '2025-11-27T20:00:00'
      },
      {
        id: 'dc5',
        userName: 'Noah Williams',
        userEmail: 'noah.w@email.com',
        userPhone: '+1 (555) 905-6789',
        discountTitle: '20% Off on Weekday Lunch',
        discountCode: 'DUOSE3N7L6',
        claimedAt: '2025-11-26T20:35:00',
        isRedeemed: false
      },
      {
        id: 'dc6',
        userName: 'Isabella Garcia',
        userEmail: 'isabella.g@email.com',
        userPhone: '+1 (555) 906-7890',
        discountTitle: 'Complimentary Dessert',
        discountCode: 'DUOSF4O8M7',
        claimedAt: '2025-11-26T15:20:00',
        isRedeemed: true,
        redeemedAt: '2025-11-26T18:45:00'
      },
      {
        id: 'dc7',
        userName: 'Ethan Davis',
        userEmail: 'ethan.d@email.com',
        userPhone: '+1 (555) 907-8901',
        discountTitle: '20% Off on Weekday Lunch',
        discountCode: 'DUOSG5P9N8',
        claimedAt: '2025-11-25T11:10:00',
        isRedeemed: true,
        redeemedAt: '2025-11-25T12:30:00'
      }
    ]
  },
  '2': { // Zenith Wellness Spa
    brandId: '2',
    totalProfileViews: 528,
    totalDiscountClaims: 156,
    totalRedemptions: 112,
    profileViews: [
      {
        id: 'pv9',
        userName: 'Grace Wilson',
        userEmail: 'grace.w@email.com',
        viewedAt: '2025-11-29T11:00:00',
        duration: 280,
        deviceType: 'Desktop'
      },
      {
        id: 'pv10',
        userName: 'Daniel Lee',
        userEmail: 'daniel.l@email.com',
        viewedAt: '2025-11-29T08:30:00',
        duration: 195,
        deviceType: 'Mobile'
      },
      {
        id: 'pv11',
        userName: 'Mia Anderson',
        userEmail: 'mia.a@email.com',
        viewedAt: '2025-11-28T17:15:00',
        duration: 340,
        deviceType: 'Tablet'
      },
      {
        id: 'pv12',
        userName: 'Alexander Brown',
        userEmail: 'alex.b@email.com',
        viewedAt: '2025-11-28T13:45:00',
        duration: 220,
        deviceType: 'Desktop'
      }
    ],
    discountClaims: [
      {
        id: 'dc8',
        userName: 'Grace Wilson',
        userEmail: 'grace.w@email.com',
        userPhone: '+1 (555) 908-9012',
        discountTitle: '30% Off First Visit',
        discountCode: 'DUOSH6Q1O9',
        claimedAt: '2025-11-29T11:10:00',
        isRedeemed: false
      },
      {
        id: 'dc9',
        userName: 'Mia Anderson',
        userEmail: 'mia.a@email.com',
        userPhone: '+1 (555) 909-0123',
        discountTitle: 'Couple Package Special',
        discountCode: 'DUOSI7R2P1',
        claimedAt: '2025-11-28T17:20:00',
        isRedeemed: true,
        redeemedAt: '2025-11-29T10:00:00'
      },
      {
        id: 'dc10',
        userName: 'Alexander Brown',
        userEmail: 'alex.b@email.com',
        userPhone: '+1 (555) 910-1234',
        discountTitle: '30% Off First Visit',
        discountCode: 'DUOSJ8S3Q2',
        claimedAt: '2025-11-28T13:50:00',
        isRedeemed: true,
        redeemedAt: '2025-11-28T15:30:00'
      }
    ]
  },
  '3': { // Paradise Cove Resort
    brandId: '3',
    totalProfileViews: 1247,
    totalDiscountClaims: 287,
    totalRedemptions: 198,
    profileViews: [
      {
        id: 'pv13',
        userName: 'Charlotte Taylor',
        userEmail: 'charlotte.t@email.com',
        viewedAt: '2025-11-29T09:00:00',
        duration: 420,
        deviceType: 'Desktop'
      },
      {
        id: 'pv14',
        userName: 'Benjamin Moore',
        userEmail: 'ben.m@email.com',
        viewedAt: '2025-11-28T21:30:00',
        duration: 380,
        deviceType: 'Mobile'
      },
      {
        id: 'pv15',
        userName: 'Amelia Clark',
        userEmail: 'amelia.c@email.com',
        viewedAt: '2025-11-28T15:00:00',
        duration: 290,
        deviceType: 'Desktop'
      }
    ],
    discountClaims: [
      {
        id: 'dc11',
        userName: 'Charlotte Taylor',
        userEmail: 'charlotte.t@email.com',
        userPhone: '+1 (555) 911-2345',
        discountTitle: 'Early Bird Special - 25% Off',
        discountCode: 'DUOSK9T4R3',
        claimedAt: '2025-11-29T09:15:00',
        isRedeemed: false
      },
      {
        id: 'dc12',
        userName: 'Benjamin Moore',
        userEmail: 'ben.m@email.com',
        userPhone: '+1 (555) 912-3456',
        discountTitle: 'Extended Stay Discount',
        discountCode: 'DUOSL1U5S4',
        claimedAt: '2025-11-28T21:40:00',
        isRedeemed: false
      }
    ]
  }
};

export function getAnalytics(brandId: string): BrandAnalytics | null {
  return analyticsData[brandId] || null;
}
