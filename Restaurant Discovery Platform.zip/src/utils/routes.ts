import { createBrowserRouter } from "react-router";
import { Layout } from "../components/Layout";
import { Home } from "../components/Home";
import { BrandDetail } from "../components/BrandDetail";
import { PartnerDashboard } from "../components/PartnerDashboard";
import { AdminDashboard } from "../components/AdminDashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "brand/:id", Component: BrandDetail },
      { path: "partner/:id", Component: PartnerDashboard },
      { path: "admin", Component: AdminDashboard },
    ],
  },
]);