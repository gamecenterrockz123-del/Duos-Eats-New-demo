export interface MonthlyRevenue {
  month: string;
  revenue: number;
  subscriptions: number;
}

export interface AdminStats {
  totalRevenue: number;
  totalRestaurants: number;
  registeredUsers: number;
  totalVisitors: number;
  discountRedemptions: number;
}

export interface RecentSubscription {
  id: string;
  restaurantName: string;
  plan: string;
  amount: number;
  date: string;
  status: 'active' | 'pending' | 'expired';
}

export interface RestaurantAnalytics {
  id: string;
  name: string;
  category: string;
  profileVisits: number;
  discountClaims: number;
  conversionRate: number;
  subscriptionPlan: string;
  lastActive: string;
}

export const monthlyRevenueData: MonthlyRevenue[] = [
  { month: 'Jan', revenue: 12500, subscriptions: 5 },
  { month: 'Feb', revenue: 15000, subscriptions: 6 },
  { month: 'Mar', revenue: 18500, subscriptions: 7 },
  { month: 'Apr', revenue: 22000, subscriptions: 8 },
  { month: 'May', revenue: 27500, subscriptions: 11 },
  { month: 'Jun', revenue: 31000, subscriptions: 12 },
  { month: 'Jul', revenue: 35500, subscriptions: 14 },
  { month: 'Aug', revenue: 42000, subscriptions: 16 },
  { month: 'Sep', revenue: 48500, subscriptions: 19 },
  { month: 'Oct', revenue: 52000, subscriptions: 20 },
  { month: 'Nov', revenue: 57500, subscriptions: 23 },
  { month: 'Dec', revenue: 65000, subscriptions: 25 },
];

export const userGrowthData = [
  { month: 'Jan', users: 120 },
  { month: 'Feb', users: 185 },
  { month: 'Mar', users: 245 },
  { month: 'Apr', users: 320 },
  { month: 'May', users: 425 },
  { month: 'Jun', users: 580 },
  { month: 'Jul', users: 720 },
  { month: 'Aug', users: 890 },
  { month: 'Sep', users: 1050 },
  { month: 'Oct', users: 1240 },
  { month: 'Nov', users: 1420 },
  { month: 'Dec', users: 1680 },
];

export const discountRedemptionData = [
  { month: 'Jan', redemptions: 45 },
  { month: 'Feb', redemptions: 68 },
  { month: 'Mar', redemptions: 92 },
  { month: 'Apr', redemptions: 115 },
  { month: 'May', redemptions: 148 },
  { month: 'Jun', redemptions: 185 },
  { month: 'Jul', redemptions: 220 },
  { month: 'Aug', redemptions: 265 },
  { month: 'Sep', redemptions: 310 },
  { month: 'Oct', redemptions: 358 },
  { month: 'Nov', redemptions: 405 },
  { month: 'Dec', redemptions: 468 },
];

export const adminStats: AdminStats = {
  totalRevenue: 427000,
  totalRestaurants: 25,
  registeredUsers: 1680,
  totalVisitors: 12450,
  discountRedemptions: 2679,
};

export const recentSubscriptions: RecentSubscription[] = [
  {
    id: '1',
    restaurantName: 'Sakura Sushi Bar',
    plan: 'Premium',
    amount: 2500,
    date: '2024-12-15',
    status: 'active',
  },
  {
    id: '2',
    restaurantName: 'The Golden Fork',
    plan: 'Standard',
    amount: 1500,
    date: '2024-12-12',
    status: 'active',
  },
  {
    id: '3',
    restaurantName: 'Coastal Breeze Resort',
    plan: 'Premium',
    amount: 2500,
    date: '2024-12-10',
    status: 'active',
  },
  {
    id: '4',
    restaurantName: 'Urban Brew Coffee',
    plan: 'Basic',
    amount: 999,
    date: '2024-12-08',
    status: 'active',
  },
  {
    id: '5',
    restaurantName: 'Spice Route Indian',
    plan: 'Standard',
    amount: 1500,
    date: '2024-12-05',
    status: 'pending',
  },
];

export const subscriptionPlans = [
  {
    name: 'Basic',
    price: 999,
    features: ['Profile listing', 'Basic analytics', 'Email support'],
    count: 8,
  },
  {
    name: 'Standard',
    price: 1500,
    features: ['Everything in Basic', 'Featured placement', 'Advanced analytics', 'Priority support'],
    count: 10,
  },
  {
    name: 'Premium',
    price: 2500,
    features: ['Everything in Standard', 'Top placement', 'Custom branding', 'Dedicated account manager'],
    count: 7,
  },
];

export const restaurantAnalytics: RestaurantAnalytics[] = [
  {
    id: '1',
    name: 'Sakura Sushi Bar',
    category: 'Restaurant',
    profileVisits: 1245,
    discountClaims: 189,
    conversionRate: 15.2,
    subscriptionPlan: 'Premium',
    lastActive: '2024-12-15',
  },
  {
    id: '2',
    name: 'The Golden Fork',
    category: 'Restaurant',
    profileVisits: 987,
    discountClaims: 142,
    conversionRate: 14.4,
    subscriptionPlan: 'Standard',
    lastActive: '2024-12-14',
  },
  {
    id: '3',
    name: 'Coastal Breeze Resort',
    category: 'Resort',
    profileVisits: 2156,
    discountClaims: 312,
    conversionRate: 14.5,
    subscriptionPlan: 'Premium',
    lastActive: '2024-12-15',
  },
  {
    id: '4',
    name: 'Urban Brew Coffee',
    category: 'Lifestyle',
    profileVisits: 756,
    discountClaims: 98,
    conversionRate: 13.0,
    subscriptionPlan: 'Basic',
    lastActive: '2024-12-13',
  },
  {
    id: '5',
    name: 'Spice Route Indian',
    category: 'Restaurant',
    profileVisits: 1432,
    discountClaims: 234,
    conversionRate: 16.3,
    subscriptionPlan: 'Standard',
    lastActive: '2024-12-15',
  },
  {
    id: '6',
    name: 'Mountain Peak Lodge',
    category: 'Resort',
    profileVisits: 1678,
    discountClaims: 245,
    conversionRate: 14.6,
    subscriptionPlan: 'Premium',
    lastActive: '2024-12-14',
  },
  {
    id: '7',
    name: 'Artisan Bakery & Cafe',
    category: 'Lifestyle',
    profileVisits: 892,
    discountClaims: 156,
    conversionRate: 17.5,
    subscriptionPlan: 'Standard',
    lastActive: '2024-12-15',
  },
  {
    id: '8',
    name: 'Ocean View Seafood',
    category: 'Restaurant',
    profileVisits: 1123,
    discountClaims: 167,
    conversionRate: 14.9,
    subscriptionPlan: 'Standard',
    lastActive: '2024-12-12',
  },
  {
    id: '9',
    name: 'Wellness Spa & Retreat',
    category: 'Lifestyle',
    profileVisits: 1534,
    discountClaims: 198,
    conversionRate: 12.9,
    subscriptionPlan: 'Premium',
    lastActive: '2024-12-15',
  },
  {
    id: '10',
    name: 'Pizza Perfetto',
    category: 'Restaurant',
    profileVisits: 1876,
    discountClaims: 289,
    conversionRate: 15.4,
    subscriptionPlan: 'Basic',
    lastActive: '2024-12-15',
  },
  {
    id: '11',
    name: 'Tropical Paradise Resort',
    category: 'Resort',
    profileVisits: 2345,
    discountClaims: 367,
    conversionRate: 15.7,
    subscriptionPlan: 'Premium',
    lastActive: '2024-12-14',
  },
  {
    id: '12',
    name: 'Vintage Wine Bar',
    category: 'Lifestyle',
    profileVisits: 1098,
    discountClaims: 178,
    conversionRate: 16.2,
    subscriptionPlan: 'Standard',
    lastActive: '2024-12-13',
  },
];